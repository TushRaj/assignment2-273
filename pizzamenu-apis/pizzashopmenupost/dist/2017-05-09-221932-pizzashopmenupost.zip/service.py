import boto3

def handler(event, context):
    # Your code goes here!
    client = boto3.clint("dynamodb")

    try:
        client.put_item(Tablename = "pizzashopmenu", item = event)


   except Exception,e:
       return 400

    return 500, "okay "