# -*- coding: utf-8 -*-

import boto3

def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")
    return client.get_item(TableName="pizzashopmenu", Key = event)